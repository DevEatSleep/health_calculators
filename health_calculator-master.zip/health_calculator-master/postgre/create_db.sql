-- Database: health_calculators

-- DROP DATABASE health_calculators;

CREATE DATABASE health_calculators
    WITH 
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'C'
    LC_CTYPE = 'C'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;